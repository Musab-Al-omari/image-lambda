# image-lambda


first: we go to AWS Lambda and we create a function  we name the function 
second u create a a trigger  for it  we choose a s3  then we choose our boucket 
